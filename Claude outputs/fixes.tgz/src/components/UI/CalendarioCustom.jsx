import { useState, useEffect } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { verificarSeFeriado } from '../../utils/feriados';
import { API_BASE, IS_API_AVAILABLE } from '../../utils/api';
import { usePreferencias } from '../../hooks/usePreferencias';

const CHAVE_RESERVAS = 'recanto_camargo_reservas';

// Dois meses lado a lado a partir desta largura de tela (no celular, um mês por vez).
const LARGURA_DOIS_MESES = 768;

function useDoisMeses(ativo) {
  const [largo, setLargo] = useState(() => typeof window !== 'undefined' && window.innerWidth >= LARGURA_DOIS_MESES);
  useEffect(() => {
    if (!ativo) return undefined;
    const aoRedimensionar = () => setLargo(window.innerWidth >= LARGURA_DOIS_MESES);
    window.addEventListener('resize', aoRedimensionar);
    return () => window.removeEventListener('resize', aoRedimensionar);
  }, [ativo]);
  return ativo && largo;
}

// variante "duplo": visual estilo Airbnb, dois meses, e permite escolher a entrada e depois a saída
// (o onChange recebe [entrada, null] no primeiro clique).
function CalendarioCustom({ valor, onChange, minDate, imovelId = 1, duplo = false }) {
  const { t, idioma } = usePreferencias();
  const doisMeses = useDoisMeses(duplo);
  const [reservas, setReservas] = useState([]);
  const [erroConflito, setErroConflito] = useState('');

  useEffect(() => {
    if (IS_API_AVAILABLE) {
      fetch(`${API_BASE}/api/reservas/datas-ocupadas?imovelId=${encodeURIComponent(imovelId)}`)
        .then(res => res.json())
        .then(data => setReservas(Array.isArray(data) ? data : []))
        .catch(err => console.error('Erro ao carregar datas ocupadas:', err));
    } else {
      try {
        const locais = JSON.parse(localStorage.getItem(CHAVE_RESERVAS) || '[]');
        setReservas(Array.isArray(locais) ? locais : []);
      } catch {
        setReservas([]);
      }
    }
  }, [imovelId]);

  const handleCalendarChange = (range) => {
    setErroConflito('');
    if (duplo && Array.isArray(range) && range[0] && !range[1]) {
      onChange?.(range);
      return;
    }
    if (Array.isArray(range) && range[0] && range[1]) {
      const startIso = new Date(range[0].getTime() - range[0].getTimezoneOffset() * 60000).toISOString().split('T')[0];
      const endIso = new Date(range[1].getTime() - range[1].getTimezoneOffset() * 60000).toISOString().split('T')[0];
      
      const conflito = reservas.some(r => {
        if (r.status === 'cancelada') return false;
        return startIso < r.checkout && endIso > r.checkin;
      });

      if (conflito) {
        setErroConflito('O período selecionado cruza com datas já reservadas. Por favor, ajuste sua seleção.');
        return;
      }
    }
    onChange?.(range);
  };

  const tileClassName = ({ date, view }) => {
    if (view !== 'month') return null;
    let classes = [];
    
    const dIso = new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().split('T')[0];
    
    // Dia inteiramente ocupado (no meio de uma reserva ou com troca no mesmo dia)
    const ocupadoMeio = reservas.some(r => r.status !== 'cancelada' && dIso > r.checkin && dIso < r.checkout);
    const temCheckin = reservas.some(r => r.status !== 'cancelada' && dIso === r.checkin);
    const temCheckout = reservas.some(r => r.status !== 'cancelada' && dIso === r.checkout);
    
    const isBooked = ocupadoMeio || (temCheckin && temCheckout);
    const isCheckin = !isBooked && temCheckin;
    const isCheckout = !isBooked && temCheckout;

    if (isBooked) classes.push('react-calendar__tile--reservado');
    else if (isCheckin) classes.push('dia-checkin-ocupado');
    else if (isCheckout) classes.push('dia-checkout-ocupado');

    if (verificarSeFeriado(date)) classes.push('dia-feriado');
    if (date.getDay() === 0 || date.getDay() === 6) classes.push('dia-fim-semana');
    
    return classes.join(' ');
  };

  const tileDisabled = ({ date, view }) => {
    if (view !== 'month') return false;
    const dIso = new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().split('T')[0];
    
    const ocupadoMeio = reservas.some(r => r.status !== 'cancelada' && dIso > r.checkin && dIso < r.checkout);
    const temCheckin = reservas.some(r => r.status !== 'cancelada' && dIso === r.checkin);
    const temCheckout = reservas.some(r => r.status !== 'cancelada' && dIso === r.checkout);
    
    return ocupadoMeio || (temCheckin && temCheckout);
  };

  return (
    <>
      <Calendar
        className={`custom-calendar-home${duplo ? ' rc-cal' : ''}`}
        onChange={handleCalendarChange}
        value={valor}
        selectRange={true}
        allowPartialRange={duplo}
        showDoubleView={doisMeses}
        prev2Label={duplo ? null : undefined}
        next2Label={duplo ? null : undefined}
        prevLabel={duplo ? <i className="bi bi-chevron-left" aria-hidden="true" /> : undefined}
        nextLabel={duplo ? <i className="bi bi-chevron-right" aria-hidden="true" /> : undefined}
        formatShortWeekday={duplo ? (locale, date) => date.toLocaleDateString(locale, { weekday: 'narrow' }) : undefined}
        minDate={minDate || new Date()}
        tileClassName={tileClassName}
        tileDisabled={tileDisabled}
        locale={duplo && idioma === "en" ? "en-US" : "pt-BR"}
        showFixedNumberOfWeeks={!duplo}
        showNeighboringMonth={!duplo}
      />
      {erroConflito && (
        <div 
          className="alert alert-danger py-2 px-3 mt-2 mb-2 small d-flex align-items-center rounded-3 border-0 shadow-sm"
          style={{ backgroundColor: '#fce8e6', color: '#c5221f', fontSize: '13px', lineHeight: '1.4' }}
        >
          <i className="bi bi-exclamation-triangle-fill me-2 fs-6 flex-shrink-0"></i>
          <span>{erroConflito}</span>
        </div>
      )}
      {duplo ? (
        <div className="rc-cal-legenda">
          <span><i className="rc-cal-leg-ocupado" aria-hidden="true" /> {t('Indisponível')}</span>
          <span><i className="rc-cal-leg-feriado" aria-hidden="true" /> {t('Feriado')}</span>
        </div>
      ) : (
      <div className="calendario-legenda mt-2 d-flex flex-wrap gap-2">
        <div className="legenda-item"><div className="legenda-cor selecionado"></div> Selecionado</div>
        <div className="legenda-item"><div className="legenda-cor reservado"></div> Indisponível</div>
        <div className="legenda-item" title="Manhã ocupada por checkout anterior, tarde livre para sua entrada"><div className="legenda-cor checkout-ocupado"></div> Saída</div>
        <div className="legenda-item" title="Manhã livre para sua saída, tarde ocupada por novo hóspede"><div className="legenda-cor checkin-ocupado"></div> Entrada</div>
        <div className="legenda-item"><div className="legenda-cor feriado"></div> Feriado</div>
      </div>
      )}
    </>
  );
}

export default CalendarioCustom;
